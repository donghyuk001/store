﻿// bookDIg.cpp: 구현 파일
//

#include "pch.h"
#include "객체지향언어기말프로젝트.h"
#include "afxdialogex.h"
#include "bookDIg.h"

#include "객체지향언어기말프로젝트Doc.h"
#include "객체지향언어기말프로젝트View.h"

#include <afxinet.h>
#include <string>
#include <afxdlgs.h>

// 서버 주소
//#define SERVER_IP _T("127.0.0.1")
//#define SERVER_PORT 8080

IMPLEMENT_DYNAMIC(bookDIg, CDialogEx)

bookDIg::bookDIg(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_Book_reg, pParent), m_bookId(0)
{
	bookView = (C객체지향언어기말프로젝트View*)pParent;
}

bookDIg::~bookDIg()
{
}

void bookDIg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_EDIT1, bec1);
	DDX_Control(pDX, IDC_EDIT2, bec2);
	DDX_Control(pDX, IDC_EDIT3, bec3);
	DDX_Control(pDX, IDC_COMBO1, bcb1);
}

BEGIN_MESSAGE_MAP(bookDIg, CDialogEx)
	ON_BN_CLICKED(ID_BookReg, &bookDIg::OnBnClickedBookreg)
	ON_BN_CLICKED(IDC_BookUpdate, &bookDIg::OnBnClickedBookupdate)
	ON_BN_CLICKED(IDC_BookDel, &bookDIg::OnBnClickedBookdel)
	ON_BN_CLICKED(IDC_BookImg, &bookDIg::OnBnClickedBookimg)
	/*ON_BN_CLICKED(IDC_BookClose, &bookDIg::OnBnClickedBookclose)*/
END_MESSAGE_MAP()




void bookDIg::LoadServerInfo(CString& strServer, INTERNET_PORT& nPort, DWORD& dwSecure, DWORD& dwSecureFlag)
{
	LPCTSTR lpszIniPath = _T(".\\config.ini");
	TCHAR szHost[256];
	::GetPrivateProfileString(_T("Server"), _T("Host"), _T("localhost"), szHost, 256, lpszIniPath);
	strServer = szHost;

	TCHAR szPort[64];
	::GetPrivateProfileString(_T("Server"), _T("Port"), _T("8080"), szPort, 64, lpszIniPath);

	if (CString(szPort).CompareNoCase(_T("INTERNET_DEFAULT_HTTPS_PORT")) == 0) {
		nPort = INTERNET_DEFAULT_HTTPS_PORT;
	}
	else {
		nPort = (INTERNET_PORT)_ttoi(szPort);
	}

	dwSecure = ::GetPrivateProfileInt(_T("Server"), _T("Secure"), 0, lpszIniPath);
	dwSecureFlag = (dwSecure == 1) ? INTERNET_FLAG_SECURE : 0;
}

void bookDIg::OnBnClickedBookreg()
{
	

	CString strTitle, strAuthor, strPublisher, strCategory;

	USES_CONVERSION;

	bec1.GetWindowText(strTitle);
	bec2.GetWindowText(strAuthor);
	bec3.GetWindowText(strPublisher);

	int nCurSel = bcb1.GetCurSel();
	if (nCurSel != CB_ERR)
		bcb1.GetLBText(nCurSel, strCategory);

	if (strTitle.IsEmpty() || strAuthor.IsEmpty() || strCategory.IsEmpty())
	{
		AfxMessageBox(_T("제목, 저자, 카테고리는 필수 입력 사항입니다."));
		return;
	}

	
	LPCTSTR lpszIniPath = _T(".\\config.ini");
	TCHAR szHost[256];
	::GetPrivateProfileString(_T("Server"), _T("Host"), _T("localhost"), szHost, 256, lpszIniPath);
	CString strServer = szHost;

	TCHAR szPort[64];
	::GetPrivateProfileString(_T("Server"), _T("Port"), _T("8080"), szPort, 64, lpszIniPath);

	INTERNET_PORT nPort;
	if (CString(szPort).CompareNoCase(_T("INTERNET_DEFAULT_HTTPS_PORT")) == 0) {
		nPort = INTERNET_DEFAULT_HTTPS_PORT;
	}
	else {
		nPort = (INTERNET_PORT)_ttoi(szPort);
	}

	DWORD dwSecure = ::GetPrivateProfileInt(_T("Server"), _T("Secure"), 0, lpszIniPath);
	DWORD dwSecureFlag = (dwSecure == 1) ? INTERNET_FLAG_SECURE : 0;
	
	CStringA base64Image = "";
	if (!m_strImagePath.IsEmpty())
	{
		CFile file;
		if (file.Open(m_strImagePath, CFile::modeRead | CFile::typeBinary))
		{
			DWORD fsize = file.GetLength();
			BYTE* buffer = new BYTE[fsize];

			file.Read(buffer, fsize);
			file.Close();

			base64Image = Base64Encode(buffer, fsize);
			delete[] buffer;
		}
	}

	
	CStringA category_utf8 = CW2A(strCategory, CP_UTF8);
	CStringA title_utf8 = CW2A(strTitle, CP_UTF8);
	CStringA author_utf8 = CW2A(strAuthor, CP_UTF8);
	CStringA publisher_utf8 = CW2A(strPublisher, CP_UTF8);

	
	CStringA json;
	json += "{";
	json += "\"title\":\"" + title_utf8 + "\",";
	json += "\"author\":\"" + author_utf8 + "\",";
	json += "\"category\":\"" + category_utf8 + "\",";
	json += "\"publisher\":\"" + publisher_utf8 + "\",";
	json += "\"imageBase64\":\"" + base64Image + "\"";
	json += "}";

	
	CInternetSession session(_T("BookClientJSON"));
	CHttpConnection* pConnection = nullptr;
	CHttpFile* pFile = nullptr;

	try
	{
		
		pConnection = session.GetHttpConnection(strServer, nPort);

		
		DWORD dwFlags = dwSecureFlag | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
		dwFlags |= INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;

		pFile = pConnection->OpenRequest(
			CHttpConnection::HTTP_VERB_POST,
			_T("/book"),
			NULL, 1, NULL, NULL,
			dwFlags 
		);

		CString strHeaders = _T("Content-Type: application/json\r\n");

		pFile->SendRequest(strHeaders, (DWORD)strHeaders.GetLength(),
			(LPVOID)(LPCSTR)json, json.GetLength());

		DWORD dwStatus = 0;
		pFile->QueryInfoStatusCode(dwStatus);

		if (dwStatus == 200 || dwStatus == 201)
		{
			AfxMessageBox(_T("도서 등록 성공!"));
			
			if (bookView) {
				bookView->OnBnClickedMainsearch(); 
			}
			OnCancel();
		}
		else
		{
			CString msg;
			msg.Format(_T("서버 응답 코드 : %u"), dwStatus);
			AfxMessageBox(msg);
		}
	}
	catch (CInternetException* e)
	{
		TCHAR err[512];
		e->GetErrorMessage(err, 512);
		AfxMessageBox(err);
		e->Delete();
	}

	if (pFile) { pFile->Close(); delete pFile; }
	if (pConnection) { pConnection->Close(); delete pConnection; }
	session.Close();
}

void bookDIg::OnBnClickedBookupdate()
{
	if (m_bookId == 0) {
		AfxMessageBox(_T("수정할 도서 ID가 없습니다."));
		return;
	}

	CString title, author, publisher, category;

	bec1.GetWindowText(title);
	bec2.GetWindowText(author);
	bec3.GetWindowText(publisher);

	int sel = bcb1.GetCurSel();
	if (sel != CB_ERR)
		bcb1.GetLBText(sel, category);

	if (title.IsEmpty() || author.IsEmpty() || category.IsEmpty())
	{
		AfxMessageBox(_T("제목, 저자, 카테고리는 필수입니다."));
		return;
	}

	
	USES_CONVERSION;
	CStringA title_utf8 = CW2A(title, CP_UTF8);
	CStringA author_utf8 = CW2A(author, CP_UTF8);
	CStringA publisher_utf8 = CW2A(publisher, CP_UTF8);
	CStringA category_utf8 = CW2A(category, CP_UTF8);

	
	CStringA json;
	json += "{";
	json += "\"title\":\"" + title_utf8 + "\",";
	json += "\"author\":\"" + author_utf8 + "\",";
	json += "\"publisher\":\"" + publisher_utf8 + "\",";
	json += "\"category\":\"" + category_utf8 + "\"";
	json += "}";



	CString strServer;
	INTERNET_PORT nPort;
	DWORD dwSecure, dwSecureFlag;
	LoadServerInfo(strServer, nPort, dwSecure, dwSecureFlag); 

	CInternetSession session(_T("BookUpdateClient"));
	CHttpConnection* pConnection = nullptr;
	CHttpFile* pFile = nullptr;

	try {
		pConnection = session.GetHttpConnection(strServer, nPort);

		CString strObject;
		strObject.Format(_T("/book/%u"), m_bookId); 

		DWORD dwFlags = dwSecureFlag | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
		dwFlags |= INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;

		pFile = pConnection->OpenRequest(
			CHttpConnection::HTTP_VERB_PUT,
			strObject,
			NULL, 1, NULL, NULL,
			dwFlags
		);

		CString strHeaders = _T("Content-Type: application/json\r\n");

		pFile->SendRequest(strHeaders, (DWORD)strHeaders.GetLength(),
			(LPVOID)(LPCSTR)json, json.GetLength());

		DWORD dwStatus = 0;
		pFile->QueryInfoStatusCode(dwStatus);

		if (dwStatus == 200)
		{
			AfxMessageBox(_T("도서 정보 수정 성공!"));
			if (bookView) {
				bookView->OnBnClickedMainsearch(); 
			}
			OnCancel();
		}
		else
		{
			CString strResponse;
			
			char buffer[1024];
			int nRead = pFile->Read(buffer, 1024);
			if (nRead > 0) {
				buffer[nRead] = '\0';
				strResponse = CString(buffer);
			}

			CString msg;
			msg.Format(_T("도서 수정 실패! 응답 코드: %u\n서버 메시지: %s"), dwStatus, strResponse);
			AfxMessageBox(msg);
		}
	}
	catch (CInternetException* e) {
		TCHAR err[512];
		e->GetErrorMessage(err, 512);
		AfxMessageBox(err);
		e->Delete();
	}

	if (pFile) { pFile->Close(); delete pFile; }
	if (pConnection) { pConnection->Close(); delete pConnection; }
	session.Close();
}

void bookDIg::OnBnClickedBookdel()
{
	// TODO
	if (m_bookId == 0) return;

	if (AfxMessageBox(_T("정말 삭제하시겠습니까?"),
		MB_YESNO | MB_ICONQUESTION) != IDYES)
		return;

	CString strServer;
	INTERNET_PORT nPort;
	DWORD dwSecure, dwSecureFlag;
	LoadServerInfo(strServer, nPort, dwSecure, dwSecureFlag);

	CInternetSession session(_T("BookDeleteClient"));
	CHttpConnection* pConnection = nullptr;
	CHttpFile* pFile = nullptr;

	try {
		pConnection = session.GetHttpConnection(strServer, nPort);

		CString strObject;
		strObject.Format(_T("/book/%u"), m_bookId);

		DWORD dwFlags = dwSecureFlag | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
		dwFlags |= INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;

		pFile = pConnection->OpenRequest(
			CHttpConnection::HTTP_VERB_DELETE,
			strObject,
			NULL, 1, NULL, NULL,
			dwFlags
		);

		pFile->SendRequest();

		DWORD dwStatus = 0;
		pFile->QueryInfoStatusCode(dwStatus);

		if (dwStatus == 200)
		{
			AfxMessageBox(_T("도서 삭제 성공!"));
			if (bookView) {
				bookView->OnBnClickedMainsearch();
			}
			OnCancel();
		}
		else
		{
			CString strResponse;

			char buffer[1024];
			int nRead = pFile->Read(buffer, 1023); 
			if (nRead > 0) {
				buffer[nRead] = '\0';

				
				CStringA ansiResponse(buffer, nRead);
				CStringW wideResponse = CA2W(ansiResponse, CP_UTF8);
				strResponse = CString(wideResponse);
			}

			CString msg;
			msg.Format(_T("도서 삭제 실패! 응답 코드: %u\n서버 메시지: %s"), dwStatus, strResponse);
			AfxMessageBox(msg);
		}
	}
	catch (CInternetException* e) {
		TCHAR err[512];
		e->GetErrorMessage(err, 512);
		AfxMessageBox(err);
		e->Delete();
	}

	if (pFile) { pFile->Close(); delete pFile; }
	if (pConnection) { pConnection->Close(); delete pConnection; }
	session.Close();
}

void bookDIg::OnBnClickedBookimg()
{
	CFileDialog dlg(TRUE, _T("png"), NULL,
		OFN_FILEMUSTEXIST | OFN_HIDEREADONLY,
		_T("Image Files (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg|All Files (*.*)|*.*||"),
		this);

	if (dlg.DoModal() == IDOK)
	{
		m_strImagePath = dlg.GetPathName();
		AfxMessageBox(_T("이미지 파일 경로가 성공적으로 저장되었습니다:\n") + m_strImagePath);
	}
}
void bookDIg::OnCancel()
{
	
	if (bookView) {
		bookView->bd = NULL;
	}
	
	CDialogEx::OnCancel();
}


BOOL bookDIg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	bcb1.AddString(_T("철학"));
	bcb1.AddString(_T("종교"));
	bcb1.AddString(_T("사회과학"));
	bcb1.AddString(_T("자연과학"));
	bcb1.AddString(_T("기술과학"));
	bcb1.AddString(_T("예술"));
	bcb1.AddString(_T("언어"));
	bcb1.AddString(_T("문학"));
	bcb1.AddString(_T("역사"));
	bcb1.AddString(_T("기타"));
	bcb1.SetCurSel(0);
	GetDlgItem(IDC_BookUpdate)->ShowWindow(SW_SHOW);
	GetDlgItem(IDC_BookDel)->ShowWindow(SW_SHOW);


	if (m_bookId > 0)
	{
		LoadBookDetail(m_bookId);
		GetDlgItem(ID_BookReg)->SetWindowText(_T("도서 수정"));
	}
	return TRUE;
}

CStringA bookDIg::Base64Encode(const BYTE* pData, DWORD length)
{
	static const char base64Chars[] =
		"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";

	CStringA encoded;
	DWORD outLen = 4 * ((length + 2) / 3);
	encoded.Preallocate(outLen);

	DWORD i = 0;
	while (i < length)
	{
		DWORD triple = 0;
		int bytes = 0;

		for (int j = 0; j < 3; j++)
		{
			triple <<= 8;
			if (i < length)
			{
				triple |= pData[i++];
				bytes++;
			}
		}

		for (int j = 0; j < 4; j++)
		{
			if (j <= (bytes))
			{
				int idx = (triple >> (18 - 6 * j)) & 0x3F;
				encoded += base64Chars[idx];
			}
			else
			{
				encoded += '=';
			}
		}
	}

	return encoded;
}
void bookDIg::LoadBookDetail(DWORD bookId)
{
	CInternetSession session(_T("BookDetailClient"));
	CHttpConnection* pConnection = nullptr;
	CHttpFile* pFile = nullptr;

	
	LPCTSTR lpszIniPath = _T(".\\config.ini");
	TCHAR szHost[256];
	::GetPrivateProfileString(_T("Server"), _T("Host"), _T("localhost"), szHost, 256, lpszIniPath);
	CString strServer = szHost;

	TCHAR szPort[64];
	::GetPrivateProfileString(_T("Server"), _T("Port"), _T("8080"), szPort, 64, lpszIniPath);

	INTERNET_PORT nPort;
	if (CString(szPort).CompareNoCase(_T("INTERNET_DEFAULT_HTTPS_PORT")) == 0) {
		nPort = INTERNET_DEFAULT_HTTPS_PORT;
	}
	else {
		nPort = (INTERNET_PORT)_ttoi(szPort);
	}

	DWORD dwSecure = ::GetPrivateProfileInt(_T("Server"), _T("Secure"), 0, lpszIniPath);
	DWORD dwSecureFlag = (dwSecure == 1) ? INTERNET_FLAG_SECURE : 0;
	

	try
	{
		
		CString strObject;
		strObject.Format(_T("/book/%u"), bookId);

		pConnection = session.GetHttpConnection(strServer, nPort);

	
		DWORD dwFlags = dwSecureFlag | INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
		dwFlags |= INTERNET_FLAG_IGNORE_CERT_CN_INVALID | INTERNET_FLAG_IGNORE_CERT_DATE_INVALID;

		pFile = pConnection->OpenRequest(_T("GET"), strObject, NULL, 1, NULL, NULL, dwFlags);
		pFile->SendRequest();

		DWORD dwRet;
		pFile->QueryInfoStatusCode(dwRet);

		if (dwRet == HTTP_STATUS_OK)
		{
			CString strResponse;
			
			DWORD dwTotalLength = 0;
			DWORD dwRead;
			CByteArray buffer;
			buffer.SetSize(4096, 4096);

			while (pFile != NULL && (dwRead = pFile->Read(buffer.GetData() + dwTotalLength, buffer.GetSize() - dwTotalLength)) > 0) {
				dwTotalLength += dwRead;
				if (dwTotalLength >= buffer.GetSize()) {
					buffer.SetSize(buffer.GetSize() + 4096, 4096);
				}
			}
			buffer.SetSize(dwTotalLength);

			if (dwTotalLength > 0) {
				int nRequiredLen = MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)buffer.GetData(), dwTotalLength, NULL, 0);
				if (nRequiredLen > 0) {
					LPTSTR pszWideChar = strResponse.GetBuffer(nRequiredLen);
					MultiByteToWideChar(CP_UTF8, 0, (LPCSTR)buffer.GetData(), dwTotalLength, pszWideChar, nRequiredLen);
					strResponse.ReleaseBuffer(nRequiredLen);
				}
			}
			
			CString jsonObj = strResponse.Trim();

			
			auto GetField = [&](CString src, CString key) -> CString {
				CString token = key + _T("\":\"");
				int start = src.Find(token);
				if (start == -1) return _T("");
				start += token.GetLength();
				int end = src.Find(_T("\""), start);
				return src.Mid(start, end - start);
				};

			CString title = GetField(jsonObj, _T("title"));
			CString author = GetField(jsonObj, _T("author"));
			CString publisher = GetField(jsonObj, _T("publisher"));
			CString category = GetField(jsonObj, _T("category"));
			CString imagePath = GetField(jsonObj, _T("imagePath")); 

			
			bec1.SetWindowText(title);
			bec2.SetWindowText(author);
			bec3.SetWindowText(publisher);

			
			int nIndex = bcb1.FindStringExact(-1, category);
			if (nIndex != CB_ERR) {
				bcb1.SetCurSel(nIndex);
			}

			m_strImagePath = imagePath;
			
		}
		else
		{
			CString msg;
			msg.Format(_T("도서 상세 정보 조회 실패! 서버 응답 코드 : %u"), dwRet);
			AfxMessageBox(msg);
		}
	}
	catch (CInternetException* e)
	{
		TCHAR err[512];
		e->GetErrorMessage(err, 512);
		AfxMessageBox(err);
		e->Delete();
	}

	if (pFile) { pFile->Close(); delete pFile; }
	if (pConnection) { pConnection->Close(); delete pConnection; }
	session.Close();
}

